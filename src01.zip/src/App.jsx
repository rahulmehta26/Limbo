import Limbo from "./components/limbo/Limbo"

const App = () => {
  return (
    <div>
      <Limbo />
    </div>
  )
}

export default App